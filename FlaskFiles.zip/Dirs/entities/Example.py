
class Example:
    def __init__(self, id, name, phoneNumber, gender):
        self.id = id
        self.name = name
        self.phoneNumber = phoneNumber
        self.gender = gender