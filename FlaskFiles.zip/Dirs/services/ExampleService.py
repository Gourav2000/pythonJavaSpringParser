
class ExampleService:
    def getAllExamples(self):
        # code to get all examples
        pass

    def saveExample(self, example):
        # code to save example
        pass